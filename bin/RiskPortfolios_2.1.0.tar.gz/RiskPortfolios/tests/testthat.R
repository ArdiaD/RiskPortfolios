library(testthat)
library(RiskPortfolios)

test_check("RiskPortfolios")
